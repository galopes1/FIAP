dicionario = {'nome': 'Paulo',
              'idade': 30,
              'email': 'paulo@email.com',
              'notas': [10, 9, 7.5]}

print(dicionario)

# Consultar
print(dicionario['nome'])
print(dicionario['idade'])
print(dicionario['email'])
print(dicionario['notas'])

# Adicionar
dicionario['cpf'] = "123.456.789-32"
print(dicionario)

# Alterar
dicionario['cpf'] = "987.654.321-01"
dicionario['idade'] = 35
print(dicionario)

# Remover um item
dicionario.pop('email')
print(dicionario)



