# Solicitar os nomes e as idades de 5 pessoas
# Armazenar os nomes em uma lista
# Armazenar as idades em outra lista
# Buscar as pessoas que possuem idade >= 18 anos

nomes = []
idades = []

# Preenche as duas listas
for i in range(5):
    nome = input("Informe o nome: ")
    idade = int(input("Informe a idade: "))
    nomes.append(nome)
    idades.append(idade)

print(nomes)
print(idades)

# Percorrer as lista
for i in range(5):                  # i = 0,1,2,3,4
    if idades[i] >= 18:
        print(f"{nomes[i]} - {idades[i]}")




