# Lista de Dicionarios
# cpf, nome, email

lista = []

for i in range(3):
    cpf = input("CPF: ")
    nome = input("NOME: ")
    email = input("EMAIL: ")
    dicionario = {'cpf': cpf,       # cria o dicionário
                  'nome': nome,
                  'email': email}
    lista.append(dicionario)        # insere o dicionario na lista

print(lista)

# Percorre a lista de dicionários
for i in range(3):
    print(lista[i])
