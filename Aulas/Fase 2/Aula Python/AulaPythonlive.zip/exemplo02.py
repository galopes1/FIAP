# PREENCHER UMA LISTA COM 10 NÚMEROS
# CONTAR A QUANTIDADE DE NÚMEROS PARES CONTIDOS NA LISTA

lista_numeros = []              # lista vazia

# Preecher a lista com números digitados pelo usuário
for i in range(10):
    numero = int(input("Informe um número: "))
    lista_numeros.append(numero)

# Exibir a lista
print(lista_numeros)

# Percorrer os itens da lista
conta_pares = 0
for indice in range(10):        # indice = 0,1,2,3,4,5,6,7,8,9
    if lista_numeros[indice] % 2 == 0:
        conta_pares += 1

print(f"Quantidade de números pares: {conta_pares}")
