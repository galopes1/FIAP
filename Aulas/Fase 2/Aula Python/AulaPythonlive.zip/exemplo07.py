def exibe_mensagem():
    print("Exemplo de Função")

def somar_numeros(a, b):
    c = a + b
    print(f"Soma dos números: {c}")

def criar_lista(tamanho):
    lista = []
    for i in range(tamanho):
        numero = int(input("Informe um número: "))
        lista.append(numero)
    return lista


# Programa principal
exibe_mensagem()                # chamada de função
somar_numeros(10, 5)            # chamdada de função
x = int(input("Informe um número: "))
y = int(input("Informe outro número: "))
somar_numeros(x, y)             # chamdada de função
lista_numero = criar_lista(5)   # chamdada de função
print(lista_numero)

lista = criar_lista(10)         # chamdada de função
print(lista)
