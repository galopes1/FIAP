# Preencher um dicionario com o cpf e nome de 5 pessoas

dicionario = {}             # dicionário vazio

# Prencher o dicionário
for i in range(5):
    cpf = input("Informe o CPF: ")
    nome = input("Informe o NOME: ")
    dicionario[cpf] = nome                  # insere no dicionario

print(dicionario)

# Percorrer apenas as chaves (cpfs)
for cpf in dicionario.keys():
    print(cpf)

# Percorrer apenas os valores (nomes)
for nome in dicionario.values():
    print(nome)

# Percorrer as chaves e valores (cpf e nome)
for cpf, nome in dicionario.items():
    print(f"{cpf} - {nome}")