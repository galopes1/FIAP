lista = [3, 5, 6, 10, 3, 5, 7]
print(lista)

# Consultar
print(lista[0])
print(lista[1])
print(lista[2])

# Alterar
lista[0] = 30
lista[3] = 100
print(lista)

# Adicionar um item no final da lista (append)
lista.append(200)
print(lista)
lista.append(300)
print(lista)

# Inserir um item em uma posição específica (insert)
lista.insert(2, 99)
print(lista)

# Remover (pop)
lista.pop(0)
print(lista)
lista.pop(5)
print(lista)

# Ordernar
lista.sort()
print(lista)

nomes = ["João", "Ana", "Pedro", "Paulo", "Maria"]
nomes.sort()
print(nomes)

# Descobrir o tamanho
tamanho = len(lista)
print(tamanho)

tamanho = len(nomes)
print(tamanho)

# Somatório de uma lista
soma = sum(lista)
print(soma)

# Média de uma lista
media = sum(lista) / len(lista)
print(media)







